# 2D转换 transform

Property: 2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/CSS3.xmind
author: pink老师
作用: 2D移动居中&2D旋转(正和负值) 三角画法 转换中心点=空格隔开 缩放
修改: Jan 7, 2021 12:53 PM
元素名-值: transform:translate(x,y);rotate(1deg);origin(x y); scale(x)
创建: Jan 5, 2021 8:11 AM
课程链接: https://www.bilibili.com/video/BV14J4114768?p=358

总结

> 居中显示以后调整宽和长时不用重新计算transform：translate(-50%,-50%);旋转方向顺和逆即正和负；右和下边框旋转rotate(45deg)； 缩放的效果 鼠标经过某标签进行放大或缩小的缩放处理

## 移动盒子的位置  ：定位  盒子的外边距  2d转换移动

## 2D 二维坐标系

![2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2D.png](2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2D.png)

![2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/css.png](2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/css.png)

![2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2Dtransformtranslate.png](2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2Dtransformtranslate.png)

![2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2Drotate.png](2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2Drotate.png)

![2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2dorigin.png](2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2dorigin.png)

![2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2d.png](2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2d.png)

![2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2d%201.png](2D%E8%BD%AC%E6%8D%A2%20transform%201d297284030d4ab28df2cd632aaf5d33/2d%201.png)

## transform的综合写法

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        div {
            width: 200px;
            height: 200px;
            background-color: pink;
            transition: all 0.5s;
        }
        div:hover {
            /* 顺序会影响转换的效果（先旋转会改变坐标轴的方向）导致位置的不同 所以移动要放到最前面*/
            transform: translate(100px,50px) rotate(180deg) scale(1.5);
        }
    </style>
</head>
<body>
    <div>

    </div>
</body>
</html>
```

scale 缩放

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        div {
            width: 200px;
            height: 200px;
            background-color: pink;
            margin: 100px auto;
            transform-origin: left bottom;
        }
        div:hover {
            /* 1.里面跟数字 不跟单位 就是 倍数的意思 1 就是 1倍 2就是 2倍 */
            /* transform: scale(x,y); */
            /* transform: scale(2,2); */
            /* 2.修改了宽度为原来的2倍 高度不变  可以小数*/
            /* transform: scale(2,1); */
            /* 3.等比例缩放 同时修改宽度和高度 简单的写法  以下是 宽度修改了两倍，高度默认和第一个一样 */
            /* transform: scale(2); */
            /* 4.缩小 小于1就是缩放 也有等比例缩放 下面的第二个*/
            /* transform: scale(0.5,0.5); */
            /* transform: scale(0.5); */
            /* 5.transform：scale的优势之处 不会影响其它的盒子 而且可以设置缩放的中心点 */
            /* width: 300px;  往左右和下边扩
            height: 300px; */
            transform: scale(2);

        }
    </style>
</head>
<body>
    <div></div>
</body>
</html>
```

盒子的转换中心点和案例

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        div {
            width: 200px;
            height: 200px;
            background-color: pink;
            margin: 100px auto;
            transition: all 1s;
            /* 1.可以跟方位名词 */
            /* transform-origin: left bottom; */
            /* 2.默认是 50% 50% 等价于 center  center */
            /* 3.可以是px 像素 */
            transform-origin: 50px 50px;
        }
        div:hover {
            transform: rotate(360deg);
        }
    </style>
</head>
<body>
    <div></div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        div {
            /* overflow: hidden; */
            width: 200px;
            height: 200px;
            border: 1px solid pink;
            margin: 100px auto;
        }
        div::before {
            content: '黑马';
            display: block;
            width: 200px;
            height: 200px;
            background-color: skyblue;
            transition: all 1s;
            transform: rotate(180deg);
            transform-origin: left bottom;
        }
        /* 鼠标经过div 里面的before复原 */
        div:hover::before {
            transform: rotate(0deg);
        }
    </style>
</head>
<body>
    <div></div>
</body>
</html>
```

## 盒子居中

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        } */
        div {
            position: relative;
            width: 500px;
            height: 500px;
            background-color: pink;
            /* 1.translate里面的参数是可以用 %  */
            /* 2.如果里面的参数是 % 移动的距离是 盒子自身的宽度或者高度来对比的 */
            /* 这里的 50% 就是 50px 因为盒子的宽度是 100px */
            /* transform: translateX(50%); */
        }   
        p {
            position: absolute;
            top: 50%;
            left: 50%;
            /* 以后修改了宽高就不管用了！ */
            /* margin: -100px 0 0 -100px; */
            width: 200px;
            height: 200px;
            background-color: purple;
            /* translate(-50%,-50%); 盒子往上和左走自己的宽度一半 以此代替margin的-值 */
            transform: translate(-50%,-50%);
        }
        span {
            /* translate对于行内元素是无效的 */
            transform: translate(300px,300px);
        }
    </style>
</head>
<body>
    <div>
        <p>2</p>
    </div>
    <span>123</span>
</body>
</html>
```

2D移动  transform:translate

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2d转换transform</title>
    <style>
        /* 盒子移动位置： 定位  盒子的外边距  2d转换 */
        div {
            width: 200px;
            height: 200px;
            background-color: pink;
            /* x 就是x轴上移动位置 y 就是y轴移动位置 中间用逗号分隔 */
            /* transform: translate(x,y); */
            /* transform: translate(100px,100px); */
            /* 1.只移动x轴 y不动 */
            /* transform: translate(100px,0); */
            /* transform: translateX(200px); */
            /* 只移动y轴 x不动 */
            /* transform: translate(0,100px); */
            /* transform: translateY(100px); */
        }
        div:first-child {
            transform: translate(100px,50px);
        }
        div:last-child {
            background-color: brown;  
        }
    </style>
</head>
<body>
    <div></div>
    <div></div>
</body>
</html>
```

2D旋转

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        img {
            width: 150px;
            border: 5px solid pink;
            border-radius: 50%;
            transition: all 1s;
        }
        img:hover {
            /* 顺时针选择270度  */
            transform: rotate(270deg);
        }
    </style>
</head>
<body>
    <img src="media/pic.jpg" alt="">
</body>
</html>
```

三角的画法

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        div {
            position: relative;
            width: 249px;
            height: 35px;
            border: 1px solid #000000;     
        }
        div::after {
            content: '';
            position: absolute;
            top: 8px;
            right: 15px;
            width: 10px;
            height: 10px;   
						/*给after 定位 大小 还有右和下的边框 旋转45度*/ 
            border-right: 1px solid #000000;
            border-bottom: 1px solid #000000;
            transition: all 1s;
            transform: rotate(45deg);
        }
        /* 鼠标经过div 里面的三角旋转 */
        div:hover::after {
            transform: rotate(225deg);
        }
    </style>
</head>
<body>
    <div></div>
</body>
</html>
```

scale 缩放的案例

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            padding:  0;
            margin: 0;
            box-sizing: border-box;
            list-style: none;
        }

        ul li {
            float: left;
            overflow: hidden;
            margin: 10px;
            width: 50px;
            height: 50px;
            text-align: center;
            line-height: 50px;
            border: 1px solid pink;
            border-radius: 50%;
            transition: all 0.2s;
        }
        ul li:hover {
            transform: scale(1.2);
        }
    </style>
</head>
<body>
    <ul>
        <li>1</li>
        <li>2</li>
        <li>3</li>
        <li>4</li>
        <li>5</li>
        <li>6</li>
        <li>7</li>
    </ul>
</body>
</html>
```